package com.example.hangman;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Button LaunchServer;
    private Button startServer;
    EditText ip;
    EditText port;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connection);


        LaunchServer = findViewById(R.id.connect_button);
        //startServer = findViewById(R.id.bt_start);

        LaunchServer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ip = findViewById(R.id.iptext);
                port = findViewById(R.id.inputport);
                if ( !ip.getText().toString().equals("127.0.0.1") ) {
                    invalid_ip();
                }else if ( !port.getText().toString().equals("6666") ){
                    invalid_port();
                }else{
                    launchActivity();
                }
            }
        });
    }

    private void invalid_ip(){
        Toast.makeText(this, "Invalid IP Address", Toast.LENGTH_SHORT).show();
    }

    private void invalid_port(){
        Toast.makeText(this, "Invalid port number", Toast.LENGTH_SHORT).show();
    }

    private void launchServer() throws Exception {
        Toast.makeText(this, R.string.started, Toast.LENGTH_SHORT).show();
    }

    private void launchActivity() {
        Intent intent = new Intent(this, MainGame.class);
        Toast.makeText(this, R.string.connected, Toast.LENGTH_SHORT).show();
        startActivity(intent);
    }
}